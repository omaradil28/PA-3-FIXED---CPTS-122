#include "header.h"

void insert_test();

void delete_test();

void shuffle_test();